<template>
  <div class="footer-basic bg-dark p-1">
    <footer class="text-white">
      <div class="social">
        <a href="#"><i class="fa-brands fa-instagram fs-2 m-2"></i></a>
        <a href="#"><i class="fa-brands fa-github-alt fs-2 m-2"></i></a>
        <a href="#"><i class="fa-brands fa-twitter fs-2 m-2"></i></a>
        <a href="#"><i class="fa-brands fa-facebook-f fs-2 m-2"></i></a>
      </div>
      <ul class="list-inline m-0 mt-2">
        <li class="list-inline-item"><p>Javiera Rodriguez</p></li> |
        <li class="list-inline-item"><p>David Valdivia</p></li> |
        <li class="list-inline-item"><p>Rodrigo Pimentel</p></li> |
        <li class="list-inline-item"><p>Orlando Altamiranda</p></li>
      </ul>
      <p class="copyright">Academia ONline © 2022</p>
    </footer>
  </div>
</template>

<style scoped>
i {
  color: white;
}

i:hover {
  color: rgb(105, 101, 101);
}
</style>
